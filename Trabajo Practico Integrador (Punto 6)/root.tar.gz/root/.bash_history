history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl
hostnamectl set-hostname TPServer
hostnamectl
nano /ect/host
nano /ect/hosts
nano /etc/hosts
nano /etc/hosts
vi /etc/hosts
nano /etc/apt/sources.list
/etc: PDF
/etc : PDF
nano /etc/apt/sources.list
vi /etc/apt/sources.list
