#!/bin/bash

mostrar_ayuda() {
	echo "==========================================================="
	echo "Script de Copias de Seguridad Automatizadas - Ayuda"
	echo "==========================================================="
	echo "Uso correcto: $0 [directorio_origen] [directorio_destino]"
	echo ""
	echo "Ejemplo: $0 /var/log /backup_dir"
	echo "==========================================================="
	exit 0
}
#aca pongo la validacion de argumentos especiales
if [ "$1" == "-help" ] || [ "$1" == "--help" ] || [-z "$1" ] || [-z "$2" ]; then
	 mostrar_ayuda

fi

#asigno variables por los argumentos posicionales

ORIGEN="$1"
DESTINO="$2"

#aca verifico la existencia real del directorio de origen en el FS
if [ ! -d "$ORIGEN" ]; then
	echo "Error: El directorio de origen '$ORIGEN' no es valido o no existe."
	exit 1
fi

#aca verifico nuevamente, pero esta vez se trata de comprobar que el directorio este disponible y montado de forma correcta.

if ! mountpoint -q "$DESTINO"; then
	echo "Error: El directorio de destino '$DESTINO' no esta disponible como punto de montaje."
	exit 1
fi

#extraccion del nombre base del directorio de origen
NOMBRE_SUFIJO=$(basename "$ORIGEN")

#Genero la fecha en formato ANSI
FECHA_ANSI=$(date + "%Y%m%d")

#defino el nombre del archivo comprimido 
ARCHIVO_SALIDA="${DESTINO}/${NOMBRE_SUFIJO}_bkp_${FECHA_ANSI}.tar.gz"

#ejecucion de la tarea de empaquetado y compresion
tar -czf "$ARCHIVO_SALIDA" -C "$ORIGEN" .

#evaluo el codigo de retorno del comando previo
if [ $? -eq 0 ]; then
	echo "Copia de seguridad realizada exitosamente: $ARCHIVO_SALIDA"
else
	echo "Ocurrio un fallo operativo al intentar procesar el backup."
	exit 1

fi

